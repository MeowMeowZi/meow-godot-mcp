@tool
extends MCPPlugin
